
export default function Home() {
  return <main className="p-10 text-xl">Placeholder content. Replace with full canvas code.</main>;
}
